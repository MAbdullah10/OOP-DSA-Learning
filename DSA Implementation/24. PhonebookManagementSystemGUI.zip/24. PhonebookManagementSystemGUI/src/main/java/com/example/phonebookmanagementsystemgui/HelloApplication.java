package com.example.dsaproject;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class PhonebookManagementSystemGUI extends Application {
    private Phonebook phonebook;

    private ListView<Contact> contactListView;
    private TextField nameTextField;
    private TextField phoneNumberTextField;
    private TextField emailTextField;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        phonebook = new Phonebook();

        primaryStage.setTitle("Phonebook Management System");

        BorderPane root = new BorderPane();
        root.setPadding(new Insets(10));

        // Create the contact list view
        contactListView = new ListView<>();
        contactListView.setItems(phonebook.getContacts());
        contactListView.setPrefWidth(200);
        contactListView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                displayContactDetails(newValue);
            }
        });

        // Create the contact details form
        GridPane formPane = createContactFormPane();

        // Create the action buttons
        HBox buttonBox = createButtonBox();

        // Add the components to the root pane
        root.setLeft(contactListView);
        root.setCenter(formPane);
        root.setBottom(buttonBox);

        Scene scene = new Scene(root, 500, 300);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private GridPane createContactFormPane() {
        GridPane gridPane = new GridPane();
        gridPane.setHgap(10);
        gridPane.setVgap(10);

        Label nameLabel = new Label("Name:");
        Label phoneNumberLabel = new Label("Phone Number:");
        Label emailLabel = new Label("Email:");

        nameTextField = new TextField();
        phoneNumberTextField = new TextField();
        emailTextField = new TextField();

        gridPane.add(nameLabel, 0, 0);
        gridPane.add(nameTextField, 1, 0);
        gridPane.add(phoneNumberLabel, 0, 1);
        gridPane.add(phoneNumberTextField, 1, 1);
        gridPane.add(emailLabel, 0, 2);
        gridPane.add(emailTextField, 1, 2);

        return gridPane;
    }

    private HBox createButtonBox() {
        Button addButton = new Button("Add");
        addButton.setOnAction(event -> addContact());

        Button updateButton = new Button("Update");
        updateButton.setOnAction(event -> updateContact());

        Button deleteButton = new Button("Delete");
        deleteButton.setOnAction(event -> deleteContact());

        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER_RIGHT);
        buttonBox.setPadding(new Insets(10));
        buttonBox.getChildren().addAll(addButton, updateButton, deleteButton);

        return buttonBox;
    }

    private void displayContactDetails(Contact contact) {
        nameTextField.setText(contact.getName());
        phoneNumberTextField.setText(contact.getPhoneNumber());
        emailTextField.setText(contact.getEmail());
    }

    private void addContact() {
        String name = nameTextField.getText();
        String phoneNumber = phoneNumberTextField.getText();
        String email = emailTextField.getText();

        if (!name.isEmpty() && !phoneNumber.isEmpty() && !email.isEmpty()) {
            phonebook.addContact(name, phoneNumber, email);
            contactListView.setItems(phonebook.getContacts());
            clearFormFields();
        }
    }

    private void updateContact() {
        Contact selectedContact = contactListView.getSelectionModel().getSelectedItem();
        if (selectedContact != null) {
            String name = nameTextField.getText();
            String phoneNumber = phoneNumberTextField.getText();
            String email = emailTextField.getText();

            if (!name.isEmpty() && !phoneNumber.isEmpty() && !email.isEmpty()) {
                phonebook.updateContact(selectedContact, name, phoneNumber, email);
                contactListView.setItems(phonebook.getContacts());
                clearFormFields();
            }
        }
    }

    private void deleteContact() {
        Contact selectedContact = contactListView.getSelectionModel().getSelectedItem();
        if (selectedContact != null) {
            phonebook.deleteContact(selectedContact);
            contactListView.setItems(phonebook.getContacts());
            clearFormFields();
        }
    }

    private void clearFormFields() {
        nameTextField.clear();
        phoneNumberTextField.clear();
        emailTextField.clear();
    }
}