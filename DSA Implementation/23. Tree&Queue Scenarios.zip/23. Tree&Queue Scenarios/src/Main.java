//Q-1 Add and test a method for the LinkedQueue class that reverses the order of the elements in the queue.
import java.util.LinkedList;
import java.util.Queue;

class LinkedQueue<T> {
    private LinkedList<T> list = new LinkedList<>();

    public void enqueue(T item) {
        list.addLast(item);
    }

    public T dequeue() {
        return list.poll();
    }

    public boolean hasItems() {
        return !list.isEmpty();
    }

    public int size() {
        return list.size();
    }

    public void reverse() {
        LinkedList<T> reversedList = new LinkedList<>();
        while (!list.isEmpty()) {
            reversedList.push(list.pop());
        }
        list = reversedList;
    }
}

//Q-2 Add and test a method for the LinkedQueue class that removes and returns the element that is second from the front, if it exists.
class LinkedQueue2<T> {
    private LinkedList<T> list = new LinkedList<>();

    public void enqueue(T item) {
        list.addLast(item);
    }

    public T dequeue() {
        return list.poll();
    }

    public boolean hasItems() {
        return !list.isEmpty();
    }

    public int size() {
        return list.size();
    }

    public T removeSecondFromFront() {
        if (list.size() < 2) {
            throw new RuntimeException("Queue does not have at least two elements");
        }
        return list.remove(1);
    }
}

//Q-3 For every algorithm, root node is given as input along with any other input (if mentioned).
//a)To find and return parent of given node?
class TreeNode {
    private int data;
    private TreeNode leftChild;
    private TreeNode rightChild;
    private TreeNode parent;

    public TreeNode(int data) {
        this.data = data;
    }

    public void setLeftChild(TreeNode leftChild) {
        this.leftChild = leftChild;
        if (leftChild != null) {
            leftChild.parent = this;
        }
    }

    public void setRightChild(TreeNode rightChild) {
        this.rightChild = rightChild;
        if (rightChild != null) {
            rightChild.parent = this;
        }
    }

    public TreeNode getParent() {
        return parent;
    }
}

//b) To find and return depth/level of given node
class TreeNode2 {
    private int data;
    private TreeNode2 leftChild;
    private TreeNode2 rightChild;

    public TreeNode2(int data) {
        this.data = data;
    }

    public int getDepth(TreeNode2 node) {
        if (node == null) {
            return -1;
        }
        int leftDepth = getDepth(node.leftChild);
        int rightDepth = getDepth(node.rightChild);
        return Math.max(leftDepth, rightDepth) + 1;
    }
}

//c) To find and return height of the tree
class TreeNode3 {
    private int data;
    private TreeNode3 leftChild;
    private TreeNode3 rightChild;

    public TreeNode3(int data) {
        this.data = data;
    }

    public int getHeight() {
        int leftHeight = (leftChild == null) ? -1 : leftChild.getHeight();
        int rightHeight = (rightChild == null) ? -1 : rightChild.getHeight();
        return Math.max(leftHeight, rightHeight) + 1;
    }
}

//d) To find if a tree is BST or not
class TreeNode4 {
    private int data;
    private TreeNode4 leftChild;
    private TreeNode4 rightChild;

    public TreeNode4(int data) {
        this.data = data;
    }

    public boolean isBST() {
        return isBST(Integer.MIN_VALUE, Integer.MAX_VALUE);
    }

    private boolean isBST(int min, int max) {
        if (data < min || data > max) {
            return false;
        }
        boolean leftBST = (leftChild == null) ? true : leftChild.isBST(min, data - 1);
        boolean rightBST = (rightChild == null) ? true : rightChild.isBST(data + 1, max);
        return leftBST && rightBST;
    }
}

//e)To find if two nodes are at same level of tree or not?
class TreeNode5 {
    private int data;
    private TreeNode5 leftChild1;
    private TreeNode5 rightChild1;

    public TreeNode5(int data) {
        this.data = data;
    }

    public boolean areNodesAtSameLevel(TreeNode5 node1, TreeNode5 node2) {
        Queue<TreeNode5> queue = new LinkedList<>();
        queue.offer(this);
        int currentLevel = 0;
        boolean foundNode1 = false;
        boolean foundNode2 = false;

        while (!queue.isEmpty()) {
            int levelSize = queue.size();
            currentLevel++;

            for (int i = 0; i < levelSize; i++) {
                TreeNode5 currentNode = queue.poll();
                if (currentNode == node1) {
                    foundNode1 = true;
                }
                if (currentNode == node2) {
                    foundNode2 = true;
                }
                if (currentNode.getLeftChild1() != null) {
                    queue.offer(currentNode.getLeftChild1());
                }
                if (currentNode.getRightChild1() != null) {
                    queue.offer(currentNode.getRightChild1());
                }
            }
            if (foundNode1 && foundNode2) {
                return true;
            } else if (foundNode1 || foundNode2) {
                return false;
            }
        }
        return false;
    }
}

//f)To find and return total number of nodes?
class TreeNode6 {
    private int data;
    private TreeNode6 leftChild;
    private TreeNode6 rightChild;

    public TreeNode6(int data) {
        this.data = data;
    }
    public int size() {
        int size = 1;
        if (leftChild != null) {
            size += leftChild.size();
        }
        if (rightChild != null) {
            size += rightChild.size();
        }
        return size;
    }
}

//Q-4 Give an algorithm for level order insertion in a binary tree using queue.
public class BinaryTree {
    private TreeNode root;

    public void levelOrderInsert(int data) {
        if (root == null) {
            root = new TreeNode(data);
            return;
        }

        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);

        while (!queue.isEmpty()) {
            TreeNode current = queue.poll();

            if (current.getLeftChild() == null) {
                current.setLeftChild(new TreeNode(data));
                return;
            } else {
                queue.offer(current.getLeftChild());
            }

            if (current.getRightChild() == null) {
                current.setRightChild(new TreeNode(data));
                return;
            } else {
                queue.offer(current.getRightChild());
            }
        }
    }
}