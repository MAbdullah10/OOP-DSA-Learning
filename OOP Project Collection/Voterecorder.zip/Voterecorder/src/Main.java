import java.util.Scanner;

class Voterecorder {
    public static String nameCandidatePresident1;
    public static String nameCandidatePresident2;
    public static String nameCandidateVicePresident1;
    public static String nameCandidateVicePresident2;
    public static int votesCandidatePresident1;
    public static int votesCandidatePresident2;
    public static int votesCandidateVicePresident1;
    public static int votesCandidateVicePresident2;
    public static int myVoteForPresident;
    public static int myVoteForVicePresident;

    enum choice {
        One(1),
        Two(2),
        Zero(0);

        int x;

        choice(int x) {
            this.x = x;
        }
    }

    public static void setCandidatesPresident(String name1, String name2) {
        nameCandidatePresident1 = name1;
        nameCandidatePresident2 = name2;
    }

    public static void setCandidatesVicePresident(String name1, String name2) {
        nameCandidateVicePresident1 = name1;
        nameCandidateVicePresident2 = name2;
    }

    public static void resetVotes() {
        votesCandidatePresident1 = 0;
        votesCandidatePresident2 = 0;
        votesCandidateVicePresident1 = 0;
        votesCandidateVicePresident2 = 0;
    }

    public static String getCurrentVotePresident() {
        return nameCandidatePresident1 + ": " + votesCandidatePresident1 + ", " +
               nameCandidatePresident2 + ": " + votesCandidatePresident2;
    }

    public static String getCurrentVoteVicePresident() {
        return nameCandidateVicePresident1 + ": " + votesCandidateVicePresident1 + ", " +
               nameCandidateVicePresident2 + ": " + votesCandidateVicePresident2;
    }

    private static boolean confirmvotes(String name1, String name2) {
        boolean y = false;
        String x = "no votes are casted";
        Scanner sc = new Scanner(System.in);
        if ((name1.equals(x)) && (name2.equals(x))) {
            System.out.println("No vote casted for any candidate");
        } else {
            System.out.println("You have casted vote for President " + name1 + " and for VicePresident " + name2);
        }
        System.out.println("Are you happy with your choices? If happy press 1. If not press 0");
        int n = sc.nextInt();
        if (n == 1) {
            y = true;
        }
        return y;
    }

    public void getAndConfirmVotes() {
        myVoteForPresident = getAVote(nameCandidatePresident1, nameCandidatePresident2);
        String v = getVotes(myVoteForPresident);
        myVoteForVicePresident = getAVote(nameCandidateVicePresident1, nameCandidateVicePresident2);

        if (myVoteForPresident == choice.Zero.x) {
            System.out.println("No votes casted for President.");
            v = "no votes are casted";
        }

        if (myVoteForVicePresident == choice.Zero.x) {
            System.out.println("No votes casted for Vice President.");
            String v1 = "no votes are casted";
            recordvotes(v, v1); // Record no votes for Vice President
            return;
        }

        if (myVoteForPresident == choice.One.x) {
            myVoteForPresident = 3;
        } else if (myVoteForPresident == choice.Two.x) {
            myVoteForPresident = 4;
        }
        String v1 = getVotes(myVoteForPresident);
        boolean b;
        boolean p;
        b = confirmvotes(v, v1);
        if (!b) {
            System.out.println("Recast your votes");
            int yo = 2;
            while (yo == 2) {
                myVoteForPresident = getAVote(nameCandidatePresident1, nameCandidatePresident2);
                v = getVotes(myVoteForPresident);
                myVoteForPresident = getAVote(nameCandidateVicePresident1, nameCandidateVicePresident2);
                if (myVoteForPresident == 1) {
                    myVoteForPresident = 3;
                } else if (myVoteForPresident == 2) {
                    myVoteForPresident = 4;
                }
                v1 = getVotes(myVoteForPresident);
                p = confirmvotes(v, v1);
                if (p) {
                    yo = 3;
                }
            }
        }
        if (b) {
            recordvotes(v, v1);
        }
    }

    private void recordvotes(String n1, String n2) {
        if (!n1.equals("no votes are casted")) {
            if (n1.equals(nameCandidatePresident1)) {
                votesCandidatePresident1++;
            } else if (n1.equals(nameCandidatePresident2)) {
                votesCandidatePresident2++;
            }
        }
        if (!n2.equals("no votes are casted")) {
            if (n2.equals(nameCandidateVicePresident1)) {
                votesCandidateVicePresident1++;
            } else if (n2.equals(nameCandidateVicePresident2)) {
                votesCandidateVicePresident2++;
            }
        }
    }

    private int getAVote(String name1, String name2) {
        choice voteOne = choice.One;
        choice voteTwo = choice.Two;
        choice voteZero = choice.Zero;
        Scanner sz = new Scanner(System.in);
        System.out.println("Enter Your Vote");
        System.out.println("Press 1 for candidate " + name1 + " and press 2 for candidate " + name2);
        System.out.println("Enter 0 if you don't want to vote");
        int vote = sz.nextInt();
        while (vote != voteOne.x && vote != voteTwo.x && vote != voteZero.x) {
            System.out.print("\n");
            System.out.println("Invalid choice");
            System.out.println("Re-Enter your choice (0, 1, 2)");
            vote = sz.nextInt();
        }
        if (vote == 1)
            System.out.println("You just gave a vote to " + name1);
        else if (vote == 2)
            System.out.println("You just gave a vote to " + name2);
        else
            System.out.println("Thanks for your response");
        return vote;
    }

    private String getVotes(int p) {
        String q = " ";
        if (p == 0)
            q = "no votes are casted";
        else if (p == 1)
            q = nameCandidatePresident1;
        else if (p == 2)
            q = nameCandidatePresident2;
        else if (p == 3)
            q = nameCandidateVicePresident1;
        else if (p == 4)
            q = nameCandidateVicePresident2;
        return q;
    }

    public static void main(String[] args) {
        Voterecorder V = new Voterecorder();
        V.setCandidatesPresident("Imran", "Nawaz");
        V.setCandidatesVicePresident("Khan", "Sharif");

        Scanner sc = new Scanner(System.in);
        for (int i = 1; i <= 5; i++)
            V.getAndConfirmVotes();

        System.out.println("Results for the election for president are as follows: ");
        System.out.println(V.getCurrentVotePresident());
        System.out.println("Results for the election for vice president are as follows: ");
        System.out.println(V.getCurrentVoteVicePresident());

        if (votesCandidatePresident1 > votesCandidatePresident2) {
            System.out.println(nameCandidatePresident1 + " has won the election for president ");
        } else if (votesCandidatePresident1 == votesCandidatePresident2) {
            System.out.println("The president election is a draw between these two candidates : ");
            System.out.println(nameCandidatePresident1);
            System.out.println(nameCandidatePresident2);
        } else {
            System.out.println(nameCandidatePresident2 + " has won the election for president ");
        }

        if (votesCandidateVicePresident1 > votesCandidateVicePresident2) {
            System.out.println(nameCandidateVicePresident1 + " has won the election for vice president ");
        } else if (votesCandidateVicePresident1 == votesCandidateVicePresident2) {
            System.out.println("The vice election is a draw between these two candidates : ");
            System.out.println(nameCandidateVicePresident1);
            System.out.println(nameCandidateVicePresident2);
        } else {
            System.out.println(nameCandidateVicePresident2 + " has won the election for vice president");
        }
    }
}
