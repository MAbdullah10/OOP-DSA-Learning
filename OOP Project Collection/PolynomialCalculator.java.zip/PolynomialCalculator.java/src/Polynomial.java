import java.util.ArrayList;

public class Polynomial {
    private int degree;
    private ArrayList<Double> coefficients;

    public Polynomial(int degree, double... coefficients) {
        setDegree(degree);
        setCoefficients(coefficients);
    }

    public Polynomial() {
        this(0, 0);
    }

    private void setCoefficients(double... coefficients) {
        this.coefficients = new ArrayList<>();
        for (double coef : coefficients) {
            this.coefficients.add(coef);
        }
    }

    public int getDegree() {
        return degree;
    }

    public void setDegree(int degree) {
        this.degree = degree;
    }

    public ArrayList<Double> getCoefficients() {
        return coefficients;
    }

    public double getCoefficient(int index) {
        if (index >= 0 && index < coefficients.size()) {
            return coefficients.get(index);
        }
        return 0.0; // Return 0 for out-of-bounds index
    }

    public String toString() {
        StringBuilder builder = new StringBuilder("P(x) = ");
        for (int i = degree; i >= 0; i--) {
            double coef = coefficients.get(i);
            if (coef != 0) {
                builder.append(coef);
                if (i > 0) {
                    builder.append("x");
                    if (i > 1) {
                        builder.append("^").append(i);
                    }
                    builder.append(" + ");
                }
            }
        }
        // Remove trailing " + "
        if (builder.substring(builder.length() - 3).equals(" + ")) {
            builder.setLength(builder.length() - 3);
        }
        return builder.toString();
    }

    public double evaluatePolynomial(int x) {
        double result = 0.0;
        for (int i = 0; i <= degree; i++) {
            result += coefficients.get(i) * Math.pow(x, i);
        }
        return result;
    }

    public void addPolynomial(Polynomial polynomialToBeAdded) {
        int maxDegree = Math.max(degree, polynomialToBeAdded.degree);
        for (int i = 0; i <= maxDegree; i++) {
            double coef1 = getCoefficient(i);
            double coef2 = polynomialToBeAdded.getCoefficient(i);
            coefficients.set(i, coef1 + coef2);
        }
        degree = maxDegree;
    }

    public static Polynomial addPolynomials(Polynomial polynomial1, Polynomial polynomial2) {
        Polynomial resultPolynomial = new Polynomial(Math.max(polynomial1.degree, polynomial2.degree));
        for (int i = 0; i <= resultPolynomial.degree; i++) {
            double coef1 = polynomial1.getCoefficient(i);
            double coef2 = polynomial2.getCoefficient(i);
            resultPolynomial.coefficients.set(i, coef1 + coef2);
        }
        return resultPolynomial;
    }
}

class PolynomialTest {
    public static void main(String[] args) {
        Polynomial polynomial1 = new Polynomial(4, 2, 3, 4, 3);
        Polynomial polynomial2 = new Polynomial(3, 6, 1, 5);

        System.out.println(polynomial1);
        System.out.println(polynomial2);

        System.out.println("Answer of Polynomial " + polynomial1 + " for x = 2 is: " + polynomial1.evaluatePolynomial(2));
        System.out.println("Answer of Polynomial " + polynomial2 + " for x = 2 is: " + polynomial2.evaluatePolynomial(2));

        System.out.println("Sum of Polynomial by Method Call on an Object (Different Degree): ");
        System.out.print("Sum of " + polynomial1 + "\n" +
                "     + " + polynomial2 + "\n");
        polynomial1.addPolynomial(polynomial2);
        System.out.println("  is = " + polynomial1);

        System.out.println("Sum of Polynomial by Static Method Call using Class Name (Same Degree): ");
        System.out.print("Sum of " + polynomial1 + "\n" +
                "     + " + polynomial2 + "\n");
        Polynomial resultPolynomial = Polynomial.addPolynomials(polynomial1, polynomial2);
        System.out.println("  is = " + resultPolynomial);
    }
}
