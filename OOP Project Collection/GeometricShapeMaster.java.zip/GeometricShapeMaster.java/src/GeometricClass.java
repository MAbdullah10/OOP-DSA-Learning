import java.util.Scanner;

abstract class GeometricClass {
    private String colour;
    private boolean filled;
    private java.util.Date DateCreated;

    protected GeometricClass() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the colour of the shape: ");
        colour = sc.nextLine();
        System.out.println("If the shape is filled enter 1, otherwise enter 0 ");
        filled = sc.nextBoolean();
        DateCreated = new java.util.Date(); // Initialize DateCreated
    }

    protected GeometricClass(String colour, boolean filled) {
        this.colour = colour;
        this.filled = filled;
        DateCreated = new java.util.Date(); // Initialize DateCreated
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public boolean isFilled() {
        return filled;
    }

    public void setFilled(boolean filled) {
        this.filled = filled;
    }

    public java.util.Date getDatecreated() {
        return DateCreated;
    }

    public String toString() {
        return "\nArea is: " + getArea() + "\nPerimeter is: " + getPerimeter() +
                "\nColour of the shape is: " + getColour() +
                "\nIs the shape filled? " + isFilled() +
                "\nDate Created: " + getDatecreated();
    }

    abstract double getArea();

    abstract double getPerimeter();
}

class Circle extends GeometricClass {
    private double radius;

    public Circle() {
        Scanner sc1 = new Scanner(System.in);
        System.out.println("Enter the radius of the circle: ");
        radius = sc1.nextDouble();
    }

    public Circle(double radius) {
        this.radius = radius;
    }

    public Circle(double radius, String colour, boolean filled) {
        super(colour, filled);
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    @Override
    public double getArea() {
        return Math.PI * radius * radius;
    }

    @Override
    public double getPerimeter() {
        return 2 * Math.PI * radius;
    }

    public double getDiameter() {
        return radius * 2;
    }
}

class Rectangle extends GeometricClass {
    private double width;
    private double height;

    public Rectangle() {
        Scanner sc2 = new Scanner(System.in);
        System.out.println("Enter the width of the rectangle: ");
        width = sc2.nextDouble();
        System.out.println("Enter the height of the rectangle: ");
        height = sc2.nextDouble();
    }

    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    public Rectangle(double width, double height, String colour, boolean filled) {
        super(colour, filled);
        this.width = width;
        this.height = height;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    @Override
    double getArea() {
        return width * height;
    }

    @Override
    double getPerimeter() {
        return 2 * (width + height);
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Creating Circle:");
        Circle circle = new Circle();
        System.out.println(circle);

        System.out.println("\nCreating Rectangle:");
        Rectangle rectangle = new Rectangle();
        System.out.println(rectangle);

        scanner.close();
    }
}
