import java.util.Random;
import java.util.Scanner;

class LinearEquation {
    private double a;
    private double b;
    private double c;
    private double d;
    private double e;
    private double f;

    public LinearEquation(double a, double b, double c, double d, double e, double f) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
    }

    public double geta() {
        return a;
    }

    public double getb() {
        return b;
    }

    public double getc() {
        return c;
    }

    public double getd() {
        return d;
    }

    public double gete() {
        return e;
    }

    public double getf() {
        return f;
    }

    public boolean isSolvable() {
        return (a * d - b * c) != 0;
    }

    public double getX() {
        if (isSolvable()) {
            return (e * d - b * f) / (a * d - b * c);
        } else {
            throw new IllegalArgumentException("The equation has no solution.");
        }
    }

    public double getY() {
        if (isSolvable()) {
            return (a * f - e * c) / (a * d - b * c);
        } else {
            throw new IllegalArgumentException("The equation has no solution.");
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a:");
        double a = sc.nextDouble();

        System.out.println("Enter b:");
        double b = sc.nextDouble();

        System.out.println("Enter c:");
        double c = sc.nextDouble();

        System.out.println("Enter d:");
        double d = sc.nextDouble();

        System.out.println("Enter e:");
        double e = sc.nextDouble();

        System.out.println("Enter f:");
        double f = sc.nextDouble();

        LinearEquation equation = new LinearEquation(a, b, c, d, e, f);

        if (equation.isSolvable()) {
            double x = equation.getX();
            double y = equation.getY();

            System.out.println("Value of x is: " + x);
            System.out.println("Value of y is: " + y);

            Random r = new Random();
            int z = r.nextInt(4);

            switch (z) {
                case 0:
                    System.out.println("X is " + x + " and y is " + y);
                    break;
                case 1:
                    System.out.println("(x,y)=(" + x + "," + y + ")");
                    break;
                case 2:
                    System.out.println("X = " + x + ", y = " + y);
                    break;
                case 3:
                    System.out.println("X = " + x + ", y = " + y);
                    break;
            }
        } else {
            Random r = new Random();
            int z = r.nextInt(4);

            switch (z) {
                case 0:
                    System.out.println("The equation has no solution.");
                    break;
                case 1:
                    System.out.println("The equation cannot be solved.");
                    break;
                case 2:
                    System.out.println("Error: no solution exists for the equation.");
                    break;
                case 3:
                    System.out.println("The equation with following coefficients is unsolvable: A = " + a + ", b = " + b + ", c = " + c + ", d = " + d + ", e = " + e + ", f = " + f);
                    break;
            }
        }
    }
}
