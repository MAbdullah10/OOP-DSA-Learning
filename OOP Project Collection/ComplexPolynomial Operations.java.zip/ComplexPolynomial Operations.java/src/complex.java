import java.util.Scanner;
import java.util.ArrayList;
import java.lang.Math;
public class Complex
{
    public double real_p;
    public double imaginary_p;
    public static Scanner sc = new Scanner(System.in);
    public Complex(double real_p,double imaginary_p)
    {
        this.imaginary_p = imaginary_p;
        this.real_p = real_p;
    }
    public static Complex addition(Complex A,Complex B)
    {
        Complex c = new Complex (0,0);
        c.real_p = A.real_p+B.real_p;
        c.imaginary_p = A.imaginary_p+B.imaginary_p;
        return c;
    }

    public static Complex subtraction (Complex A,Complex B)
    {
        Complex c1 = new Complex (0,0);
        c1.real_p = A.real_p+B.real_p;
        c1.imaginary_p = A.imaginary_p+B.imaginary_p;
        return c1;
    }
    public Complex multiplication(Complex C)
    {
        real_p = (this.real_p*C.real_p)-(this.imaginary_p*C.imaginary_p);
        imaginary_p = (this.real_p*C.imaginary_p)+(this.imaginary_p*C.real_p);
        return new Complex(real_p,imaginary_p);
    }
    public void modulus(Complex C1)
    {
        double m;
        m = Math.sqrt(C1.real_p*C1.real_p)+(C1.imaginary_p*C1.imaginary_p);
    }
    public String toString()
    {
        return "( "+real_p+","+imaginary_p+"i )";
    }
}
class Polynomial {
    private int degree;
    private ArrayList<Double> coefficients;
    public Polynomial(int degree) {
        setDegree(degree);
        setCoefficient();
    }
    public Polynomial() {
        setDegree(0);
        setCoefficient();
    }
    public Polynomial(int degree, double... coefficients) {
        setDegree(degree);
        if (coefficients.length == degree) {
            setCoefficient(coefficients);
        } else {
            System.out.println("\nYour given list of coefficients is not matching the degree of polynomial. So all coefficients are set to '0'........! \n");
            setCoefficient();
        }
    }
    private void setCoefficient(double[] coefficients) {//Helper Method used by Constructor
        this.coefficients = new ArrayList<Double>();
        for (int i = 0; i < getDegree(); i++) {
            this.coefficients.add(coefficients[i]);
        }
    }
    private void setCoefficient()
    {
        this.coefficients = new ArrayList<Double>();
        for (int i = 0; i < getDegree(); i++) {
            this.coefficients.add(0.0);
        }
    }
    public int getDegree() {
        return degree;
    }
    public void setDegree(int degree) {
        this.degree = degree;
    }
    public ArrayList<Double> getCoefficients() {
        return coefficients;
    }
    public void setCoefficients(int i, double coefficients) {
        this.coefficients.add(coefficients);
    }
    public String toString() {
        String string = "P(x) = ";
        for (int i = 0; i < this.coefficients.size(); i++) {
            String string1 = coefficients.get(i) + "x^" + (this.coefficients.size() - (i + 1));
            string = string.concat(string1);
            if (i < this.coefficients.size() - 1) {
                String string2 = " + ";
                string = string.concat(string2);
            }
        }
        return string;
    }
    public double evaluatePolynomial(int x) {
        double result = 0.0;
        for (int i = 0; i < getDegree(); i++) {
            result += this.coefficients.get(i) * Math.pow(x, i);
        }
        return result;
    }
    public void addPolynomial(Polynomial polynomialToBeAdded) {
        if (getDegree() == polynomialToBeAdded.getDegree()) {
            for (int i = 0; i < this.coefficients.size(); i++) {
                this.coefficients.set(i, this.coefficients.get(i) + polynomialToBeAdded.coefficients.get(i));
            }
        } else if (getDegree() > polynomialToBeAdded.getDegree()) {
            for (int i = 0; i < this.coefficients.size(); i++) {
                if (i < polynomialToBeAdded.getDegree())
                    this.coefficients.set(i, this.coefficients.get(i) + polynomialToBeAdded.coefficients.get(i));
            }
        } else if (getDegree() < polynomialToBeAdded.getDegree()) {
            for (int i = 0; i < polynomialToBeAdded.getDegree(); i++) {
                if (i < getDegree())
                    this.coefficients.set(i, this.coefficients.get(i) + polynomialToBeAdded.coefficients.get(i));
                else {
                    this.coefficients.add(polynomialToBeAdded.coefficients.get(i));
                    this.setDegree(getDegree() + 1);
                }
            }
        }
    }
    public static Polynomial addPolynomial(Polynomial polyn1, Polynomial polyn2) {
        Polynomial resultPolyn = new Polynomial();

        if (polyn1.getDegree() == polyn2.getDegree()) {
            resultPolyn = new Polynomial(polyn1.getDegree());
            for (int i = 0; i < polyn1.coefficients.size(); i++) {
                resultPolyn.coefficients.set(i, polyn1.coefficients.get(i) + polyn2.coefficients.get(i));
            }
        } else if (polyn1.getDegree() > polyn2.getDegree()) {
            resultPolyn = new Polynomial(polyn1.getDegree());
            for (int i = 0; i < polyn1.coefficients.size(); i++) {
                if (i < polyn2.getDegree())
                    resultPolyn.coefficients.set(i, polyn1.coefficients.get(i) + polyn2.coefficients.get(i));
                else
                    resultPolyn.coefficients.set(i, polyn1.coefficients.get(i));
            }
        } else if (polyn1.getDegree() < polyn2.getDegree()) {
            resultPolyn = new Polynomial(polyn2.getDegree());
            for (int i = 0; i < polyn2.coefficients.size(); i++) {
                if (i < polyn1.getDegree())
                    resultPolyn.coefficients.set(i, polyn1.coefficients.get(i) + polyn2.coefficients.get(i));
                else
                    resultPolyn.coefficients.set(i, polyn2.coefficients.get(i));
            }
        }
        return resultPolyn;
    }
}
public class PolynomialTest {
    public static void main(String[] args)
    {
        Scanner sc1 = new Scanner(System.in);
        Complex cx = new Complex();
        System.out.println("Enter the real part of the 1st complex number:");
        cx.real_p = sc1.nextDouble();
        System.out.println("Enter the imaginary part of the 1st complex number:");
        cx.imaginary_p = sc1.nextDouble();

        Complex cx2 =new Complex();
        System.out.println("Enter the real part of the 2nd complex number:");
        cx2.real_p = sc1.nextDouble();
        System.out.println("Enter the imaginary part of the 2nd complex number:");
        cx2.imaginary_p = sc1.nextDouble();

        System.out.println("A= " +cx);
        System.out.println("B" +cx2);

        Complex cx1 = cx.addition (cx2,cx);
        System.out.println("Addition ( " +cx1.real_p+ "+" +cx1.imaginary_p+ " )");

        Complex cx3 = cx.subtraction (cx,cx2);
        System.out.println("Subtraction (" +cx3.real_p+ "+" +cx3.imaginary_p+ ")");
        cx.multiplication (cx2);
        System.out.print ("A B = ");
        System.out.println((cx.real_p+ "+" +cx1.imaginary_p +"i"));


        Polynomial polynomial1 = new Polynomial(4, 2, 3, 4, 3);
        Polynomial polynomial2 = new Polynomial(3, 6, 1, 5);

        System.out.println();
        System.out.println(polynomial1);
        System.out.println(polynomial2);
        System.out.println();
        System.out.println("Answer of Polynomial " + polynomial1 + " for x = 2 is: " + polynomial1.evaluatePolynomial(2));
        System.out.println("Answer of Polynomial " + polynomial2 + " for x = 2 is: " + polynomial2.evaluatePolynomial(2));
        System.out.println();

        System.out.println("Sum of Polynomial by Method Call on an Object (Different Degree): ");
        System.out.print("Sum of " + polynomial1 + "\n" + "     + " + polynomial2 + "\n");
        polynomial1.addPolynomial(polynomial2);
        System.out.println("  is = " + polynomial1);

        System.out.println("Sum of Polynomial by Static Method Call using Class Name (Same Degree): ");
        System.out.print("Sum of " + polynomial1 + "\n" + "     + " + polynomial2 + "\n");
        Polynomial resultPolinomal = Polynomial.addPolynomial(polynomial1, polynomial2);
        System.out.println("  is = " + resultPolinomal);
        System.out.println();
    }
}
